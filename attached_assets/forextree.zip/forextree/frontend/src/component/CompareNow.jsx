// import { Button } from "@/components/ui/button";

export default function CompareNow() {
    return (
     <div></div>
    );
  }
  