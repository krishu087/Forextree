import { User } from "../model/users.js";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";

// we have three controller in this file
// 1. signup controller
// 2. signin/Login controller
// 3. Change password controller

// 2.signup/create user  controller

export const Signup = async (req, res) => {
  try {
    // Fetch the data from req.body
    const {
      firstName,
      lastName,
      email,
      phoneNo,
      password,
      confirm_password,
      accountType,
    } = req.body;

    console.log("Request Data:", req.body);

    // Validate the data
    if (
      !firstName ||
      !lastName ||
      !email ||
      !phoneNo ||
      !password ||
      !confirm_password
    ) {
      return res.status(400).json({
        success: false,
        message: "All fields are required",
      });
    }

    // Check if passwords match
    if (password !== confirm_password) {
      return res.status(400).json({
        success: false,
        message: "Passwords do not match",
      });
    }

    // Check if user already exists
    const existUser = await User.findOne({ email });
    if (existUser) {
      return res.status(400).json({
        success: false,
        message: "User already registered",
      });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create entry in DB
    const newUser = await User.create({
      firstName,
      lastName,
      accountType,
      email,
      phoneNo,
      password: hashedPassword,
      image: `https://ui-avatars.com/api/?name=${firstName}+${lastName}&background=random&color=000`,
    });

    // Return success response
    return res.status(201).json({
      success: true,
      message: "User registered successfully",
      data: newUser,
    });
  } catch (error) {
    console.error("Signup error:", error);
    return res.status(500).json({
      success: false,
      message: "User could not register. Please try again.",
      error: error.message,
    });
  }
};

export const login = async (req, res) => {
  try {
    // get the data from req.body
    const { email, password } = req.body;
    console.log("email:", email);
    console.log("password:", password);

    // validation the data
    if (!email || !password) {
      return res.json({
        success: false,
        message: "all field must be required",
      });
    }

    // check user exitst or
    const user = await User.findOne({ email });

    if (!user) {
      return res.json({
        success: false,
        message: "user did not register please register first",
      });
    }

    // campare the password And create jwt token after mathing password
    if (await bcrypt.compare(password, user.password)) {
      const payload = {
        email: user.email,
        id: user._id,
        accountType: user.accountType,
      };

      const token = jwt.sign(payload, process.env.JWT_SECRET, {
        expiresIn: "1d",
      });
      user.token = token;
      console.log("user.token is ", user.token);
      user.password = undefined;
      console.log("user.password is ", user.password);

      // crate cookie and send res
      const option = {
        // maxAge: '1h',
        expiresIn: "1w",
        httpOnly: true,
        // secure: false, // Set to true if you're using HTTPS
        // sameSite: 'strict',
      };

      res.cookie("token", token, option).json({
        success: true,
        message: "user loggedin succefully",
        user,
        token,
      });
    } else {
      return res.json({
        success: false,
        message: "password is incorrect",
      });
    }
  } catch (error) {
    console.log("error is ", error.message);
    return res.json({
      success: false,
      message: "could not login ",
      error: error.message,
    });
  }
};
