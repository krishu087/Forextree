import { FirmArray} from "../model/FirmArrayModel.js";
 import { FirmModal } from "../model/FirmModal.model.js";


export const createFirmData = async (req, res) => {
  try {
    console.log("Request Body:", req.body);

    const {
      firm,
      rank,
      country,
      years_in_operation,
      max_allocations,
      promo,
      actions,
      reviews,
      assets,
      platforms
    } = req.body;

    // Validate required fields
    if (!firm || !rank || !country || !years_in_operation || !max_allocations || !promo || !actions || !reviews || !assets) {
      return res.status(400).json({
        success: false,
        message: "Please provide all required data.",
      });
    }

    console.log("Data is complete.");

    // Create new firm entry
    const firmData = new FirmModal({
      firm,
      rank,
      country,
      years_in_operation,
      max_allocations,
      promo,
      actions,
      reviews,
      assets,
      platforms
    });

    await firmData.save();

    return res.status(201).json({
      success: true,
      message: "Data saved successfully.",
      data: firmData,
    });

  } catch (error) {
    console.error("Error:", error);
    return res.status(500).json({
      success: false,
      message: "Could not create the data.",
      error: error.message,
    });
  }
};





// Controller to store firm data
export const storeFirmArrayData = async (req, res) => {
  try {
    console.log("yaha par hum he")
    const firms  = req.body; // Get firms data from request body
    console.log("firm",firms);

    if (!firms || !Array.isArray(firms)) {
      return res.status(400).json({ message: "Invalid data format" });
    }

    // Store in a single document
    const firmData = new FirmArray({ firms });
    await firmData.save();

    res.status(201).json({ message: "Data stored successfully!", data: firmData });
  } catch (error) {
    console.log("Error:", error);
    res.status(500).json({ message: "Error storing data", error: error.message });
  }
};
