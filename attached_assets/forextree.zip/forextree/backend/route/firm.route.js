import { Router  } from "express";
import { createFirmData, storeFirmArrayData } from "../controller/firmData.controller.js";

const firmRouter = Router();

// firmRouter.get("/get-firm-data",createFirmData);
firmRouter.post("/create-firm-data",createFirmData);

firmRouter.post("/store-firms-full-data", storeFirmArrayData);

export default firmRouter;