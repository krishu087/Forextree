import { Router } from "express";
import { Signup,login } from "../controller/auth.controller.js";

import { authantication } from "../midlewares/auth.middelware.js";


export const authrouter = Router();


authrouter.route("/signup").post(Signup);
authrouter.route("/login").post(login);


