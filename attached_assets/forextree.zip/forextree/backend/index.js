import express from "express";
import dotenv from "dotenv"; // ✅ Corrected import
import connectDB from "./config/Connectdb.js"; // ✅ Corrected import
import firmRouter from "./route/firm.route.js";
import { authrouter } from "./route/auth.route.js";
import cors from "cors"

dotenv.config(); // ✅ Load .env variables

const app = express();
app.use(cors());
app.use(express.json());
// ✅ Middleware
app.use(cors({
    origin: 'http://localhost:5173', // replace with your frontend URL
    credentials: true, // allow cookies from frontend
  }));
  

app.use("/api/v1/firm", firmRouter); // ✅ Use firmRouter
app.use("/api/v1/user", authrouter); // ✅ Use userRouter
const port = process.env.PORT || 3000; // ✅ Use environment variable


connectDB(); // ✅ Connect to MongoDB
app.get("/", (req, res) => {
    res.send("Welcome to Node.js Express backend");
});

app.get("/user", (req, res) => {
    return res.json({
        success: true,
        message: "User data fetched successfully",
        userData: {
            name: "Krishna Panjre"
        }
    });
});

app.listen(port, () => {
    console.log(`Your project is running on http://localhost:${port}`);
});
