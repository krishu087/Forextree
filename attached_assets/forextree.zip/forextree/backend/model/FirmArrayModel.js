import mongoose from "mongoose";

const firmSchema = new mongoose.Schema({
  firms: [
    {
      firm: String,
      rank: Number,
      reviews: Number,
      country: String,
      years_in_operation: mongoose.Schema.Types.Mixed, // Supports both numbers & strings like "10+"
      assets: [String],
      platforms: [String],
      max_allocations: String,
      promo: String,
      actions: String,
    },
  ],
});

 export const FirmArray = mongoose.model("FirmArray", firmSchema);

