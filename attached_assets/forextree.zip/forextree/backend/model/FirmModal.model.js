import mongoose,{Schema} from "mongoose";

const firmSchema = new mongoose.Schema({
  firm: { type: String, required: true },
  rank: { type: Number, required: true },
  reviews: { type: Number, required: true },
  country: { type: String, required: true },
  years_in_operation: { type: mongoose.Schema.Types.Mixed, required: true },
  assets: { type: [String], required: true },
  platforms: { type: [String], default: [] },
  max_allocations: { type: String, required: true },
  promo: { type: String, required: true },
  actions: { type: String, required: true }
});

 export const FirmModal = mongoose.model('Firm', firmSchema);


